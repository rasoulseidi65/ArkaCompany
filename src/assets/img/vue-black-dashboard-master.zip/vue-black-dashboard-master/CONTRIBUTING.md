* Fork the repository
* Clone it on your PC
* `npm install` or `yarn install`
* Make changes, commit open PR

### Notes
* Please don't use jQuery or jQuery based plugins since there are many pure Vue alternatives

This project uses [vue-cli 3](https://github.com/vuejs/vue-cli).
